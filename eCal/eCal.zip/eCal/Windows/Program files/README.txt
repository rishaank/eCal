eCal Overview
eCal is an easy to use GUI calculator. This is my first GUI application. This README will give you information on eCal. This application was made with Visual Studio using vb.net. The installer was made with Inno Setup.

Help
More information can be found on my website. Give feedback here. My GitHub website is here.
Installation
eCal is currently only supported on Windows but will make its way to other operating systems like MacOS.
1.	First, go to the installation page here and download the installer.
2.	Windows might say that the file is unsafe when downloading. If you trust eCal, you can ignore this.
3.	After downloading the installer, right-click on it and check the box saying unblock then click OK.
4.	Run the installer and follow the steps on your screen to install eCal.


