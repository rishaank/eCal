eCal Overview
eCal is an easy to use GUI calculator. This is my first GUI application. This README will give you information on eCal. This application was made with Visual Studio using vb.net. The installer was made with Inno Setup.

Help
More information can be found on my website. Give feedback here. My GitHub website is here.
Updating
1.	Open eCal and click Check For Updates
2.	eCal updater will open and ask you if you installed for all users. Click Yes or No
3.	Click Check for updates
4.	If you have updates available, You will get a warning and if you accept it will update
5.	If you have updates available, choose how many users you want to update for
6.	If you don't have updates you will get a message
Installation
eCal is currently only supported on Windows but will make its way to other operating systems like MacOS.
1.	Download (save) the Windows-eCal-setup.exe (download from my GitHub page or my Website)
2.	Right-click on the file (after downloading it) and click properties
3.	Check the box that says unblock and click OK
4.	Run Windows-eCal-setup.exe and proceed with the steps on your screen
Uninstallation
Windows
1.	Open Control Panel
2.	Click view by Category 
3.	Click Uninstall a program
4.	Find Steve Chatbot and click uninstall
5.	Confirm that you want to uninstall
6.	You will get a message when eCal was successfully uninstalled
7.	If you have problems uninstalling or you want to manually uninstall, go here
Images



eCal v2.1.0 |Rishaan Kotian| README |Thank you for using eCal! 


