﻿Imports System.IO
Imports System.ComponentModel
Imports System.Net
Public Class ecalupdater
    Dim exepath As String = Application.ExecutablePath
    Public Sub eCalupdater_FirstLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        MaximizeBox = False
        'Check if multiple instances are running
        If Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName).Length > 1 Then
            Me.Close()
            Process.Start(exepath)
        End If
        'Kill eCal
        Dim proc As System.Diagnostics.Process
        Dim pList() As Process
        pList = Process.GetProcessesByName(“eCal”)
        For Each proc In pList
            proc.Kill()
        Next
        If exepath.Contains("C:\Program Files (x86)\") Then
            eCalvertext.Text = (FileVersionInfo.GetVersionInfo("C:\Program Files (x86)\eCal\eCal.exe").ProductVersion.ToString)
        Else
            eCalvertext.Text = (FileVersionInfo.GetVersionInfo(userappdata & "\eCal\eCal.exe").ProductVersion.ToString)
        End If
        If (System.IO.Directory.Exists(userdocuments & "\ecal-temp")) Then
            System.IO.Directory.Delete(userdocuments & "\ecal-temp", True)
        End If
        System.IO.Directory.CreateDirectory(userdocuments & "\ecal-temp")
        Using client As New WebClient
            'Downloading setup.exe
            'Downloading setup.exe Is to reinstall the latest eCal. I can do this because eCal currently doesn't save any settings, so reinstalling won't give a different experience than what is currently installed
            client.DownloadFile("https://drive.google.com/uc?id=1OHZumqIn1JnOqsVN2Y0kPMyc-JvAuY5-&export=download", userdocuments & "\ecal-temp\ecal-setup.exe")
            client.Dispose()
        End Using
        Latestvertext.Text = FileVersionInfo.GetVersionInfo(userdocuments & "\ecal-temp\ecal-setup.exe").ProductVersion
        My.Settings.Upgrade()
        If My.Settings.DarkModeOn = True Then
            Mode.Text = "Dark Mode: ON"
            MyBase.BackColor = Color.FromArgb(64, 64, 64)
            Checkupdate.BackColor = Color.FromArgb(64, 64, 64)
            Checkupdate.FlatStyle = FlatStyle.Flat
            Checkupdate.ForeColor = Color.White
            Checkupdate.FlatAppearance.BorderColor = Color.Gray
            ecalexit.BackColor = Color.FromArgb(64, 64, 64)
            ecalexit.FlatStyle = FlatStyle.Flat
            ecalexit.ForeColor = Color.White
            ecalexit.FlatAppearance.BorderColor = Color.Gray
            ecallaunch.BackColor = Color.FromArgb(64, 64, 64)
            ecallaunch.FlatStyle = FlatStyle.Flat
            ecallaunch.ForeColor = Color.White
            ecallaunch.FlatAppearance.BorderColor = Color.Gray
            Label1.ForeColor = Color.White
            Label2.ForeColor = Color.White
            Label3.ForeColor = Color.White
            Label4.ForeColor = Color.White
            Label5.ForeColor = Color.White
            eCalvertext.ForeColor = Color.White
            Latestvertext.ForeColor = Color.White
            Closebutton.BackColor = Color.FromArgb(64, 64, 64)
            Closebutton.FlatStyle = FlatStyle.Flat
            Closebutton.ForeColor = Color.White
            Closebutton.FlatAppearance.BorderColor = Color.Gray
            UninstallButton.BackColor = Color.FromArgb(64, 64, 64)
            UninstallButton.FlatStyle = FlatStyle.Flat
            UninstallButton.ForeColor = Color.White
            UninstallButton.FlatAppearance.BorderColor = Color.Gray
            About.BackColor = Color.FromArgb(64, 64, 64)
            About.FlatStyle = FlatStyle.Flat
            About.ForeColor = Color.White
            About.FlatAppearance.BorderColor = Color.Gray
            Mode.BackColor = Color.FromArgb(64, 64, 64)
            Mode.FlatStyle = FlatStyle.Flat
            Mode.ForeColor = Color.White
            Mode.FlatAppearance.BorderColor = Color.Gray
            RichTextBox1.BackColor = Color.FromArgb(64, 64, 64)
            RichTextBox1.ForeColor = Color.White
        End If
    End Sub

    Sub NotifyIcon1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NotifyIcon1.Click
        If Me.WindowState = FormWindowState.Minimized Then
            Me.WindowState = FormWindowState.Normal
        End If
    End Sub

    'user app data location as variable
    Dim userappdata As String = (Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) & "\Programs")
    'Creates a variable to user's documents folder
    Dim userdocuments As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)

    Private Sub Checkupdate_Click(sender As Object, e As EventArgs) Handles Checkupdate.Click
        Dim wb As New WebClient
        Dim wbhtml As String = wb.DownloadString("https://rishaankotian.wixsite.com/home/v3-0-0")
        wb.Dispose()
        'To know if string "Newest" is inside website
        Dim StringContain As Boolean = wbhtml.Contains("Newest")
        'Checks if website has "Newest"
        If StringContain = True Then
            'Shows message
            MessageBox.Show("eCal is up-to-date. You are running version " & ((eCalvertext.Text).ToString), "No updates found", MessageBoxButtons.OK)
            'If ecal is not up to date (updating code)
        ElseIf StringContain = False Then
            Dim answer1 As DialogResult = MessageBox.Show("Updates are available. Would you like to install them now? Press OK to start installing updates.", "Updates Found", MessageBoxButtons.OKCancel)
            'Asking if user wants to update
            If answer1 = DialogResult.OK Then
                'Kill eCal
                Dim kill As System.Diagnostics.Process
                Dim pList() As Process
                pList = Process.GetProcessesByName(“eCal”)
                For Each kill In pList
                    kill.Kill()
                Next
                Me.Close()
                'Uninstalling eCal depending on if installed for all users or not
                If exepath.Contains("C:\Program Files (x86)\") Then
                    Dim pHelp As New ProcessStartInfo
                    pHelp.FileName = "C:\Program Files (x86)\eCal\unins000.exe"
                    pHelp.Arguments = "/VERYSILENT"
                    pHelp.UseShellExecute = True
                    pHelp.WindowStyle = ProcessWindowStyle.Normal
                    Dim proc As Process = Process.Start(pHelp)
                Else
                    Dim pHelp4 As New ProcessStartInfo
                    pHelp4.FileName = userappdata & "\eCal\unins000.exe"
                    pHelp4.Arguments = "/VERYSILENT"
                    pHelp4.UseShellExecute = True
                    pHelp4.WindowStyle = ProcessWindowStyle.Normal
                    Dim proc4 As Process = Process.Start(pHelp4)
                End If
                'Installing newer version
                Dim pHelp2 As New ProcessStartInfo
                pHelp2.FileName = userdocuments & "/ecal-temp/ecal-setup.exe"
                pHelp2.Arguments = "/SILENT"
                pHelp2.UseShellExecute = True
                pHelp2.WindowStyle = ProcessWindowStyle.Normal
                Dim proc2 As Process = Process.Start(pHelp2)
            ElseIf answer1 = DialogResult.Cancel Then
                Me.Refresh()
            End If
        End If
    End Sub

    Private Sub Closebutton_Click(sender As Object, e As EventArgs) Handles Closebutton.Click
            Me.Close()
        End Sub

        Private Sub ecalexit_Click(sender As Object, e As EventArgs) Handles ecalexit.Click
        Dim proc3 As System.Diagnostics.Process
        Dim pList() As Process
            pList = Process.GetProcessesByName(“eCal”)
        For Each proc3 In pList
            proc3.Kill()
        Next
    End Sub

        Private Sub ecallaunch_Click(sender As Object, e As EventArgs) Handles ecallaunch.Click
        If exepath.Contains("C:\Program Files (x86)\") Then
            Process.Start("C:\Program Files (x86)\eCal\eCal.exe")
        Else
            Process.Start(userappdata & "\eCal\eCal.exe")
        End If
    End Sub

    Private Sub UninstallButton_Click(sender As Object, e As EventArgs) Handles UninstallButton.Click
        If exepath.Contains("C:\Program Files (x86)\") Then
            Dim pHelp As New ProcessStartInfo
            pHelp.FileName = "C:\Program Files (x86)\eCal\unins000.exe"
            pHelp.Arguments = "/VERYSILENT"
            pHelp.UseShellExecute = True
            pHelp.WindowStyle = ProcessWindowStyle.Normal
            Me.Close()
            Dim proc As Process = Process.Start(pHelp)
        Else
            Dim pHelp4 As New ProcessStartInfo
            pHelp4.FileName = userappdata & "\eCal\unins000.exe"
            pHelp4.Arguments = "/VERYSILENT"
            pHelp4.UseShellExecute = True
            pHelp4.WindowStyle = ProcessWindowStyle.Normal
            Me.Close()
            Dim proc4 As Process = Process.Start(pHelp4)
        End If
    End Sub

    Private Sub About_Click(sender As Object, e As EventArgs) Handles About.Click
        Dim ecalver1 As String = eCalvertext.Text
        Dim ecalupdatever As String = Application.ProductVersion
        MessageBox.Show("eCal version: " & ecalver1 & vbNewLine & "eCal Updater version:" & ecalupdatever & vbNewLine & "Developer: Rishaan Kotian (10 years old)" & vbNewLine & "Main Website: https://rishaankotian.wixsite.com/home/ecal" & vbNewLine & "GitHub: https://github.com/rishaank/eCal" & vbNewLine & "Feedback: https://docs.google.com/forms/d/e/1FAIpQLSfgiyL7RUH8CC_7mPTITcIBk7X_-jNWP258FcexjQ426rDfQA/viewform" & vbNewLine & "Thank you for supporting and using eCal!", "About eCal", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub NotifyIcon1_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick
        Me.Close()
    End Sub

    Private Sub Mode_Click(sender As Object, e As EventArgs) Handles Mode.Click
        If My.Settings.DarkModeOn = False Then
            My.Settings.DarkModeOn = True
            Mode.Text = "Dark Mode: ON"
            MyBase.BackColor = Color.FromArgb(64, 64, 64)
            Checkupdate.BackColor = Color.FromArgb(64, 64, 64)
            Checkupdate.FlatStyle = FlatStyle.Flat
            Checkupdate.ForeColor = Color.White
            Checkupdate.FlatAppearance.BorderColor = Color.Gray
            ecalexit.BackColor = Color.FromArgb(64, 64, 64)
            ecalexit.FlatStyle = FlatStyle.Flat
            ecalexit.ForeColor = Color.White
            ecalexit.FlatAppearance.BorderColor = Color.Gray
            ecallaunch.BackColor = Color.FromArgb(64, 64, 64)
            ecallaunch.FlatStyle = FlatStyle.Flat
            ecallaunch.ForeColor = Color.White
            ecallaunch.FlatAppearance.BorderColor = Color.Gray
            Label1.ForeColor = Color.White
            Label2.ForeColor = Color.White
            Label3.ForeColor = Color.White
            Label4.ForeColor = Color.White
            Label5.ForeColor = Color.White
            eCalvertext.ForeColor = Color.White
            Latestvertext.ForeColor = Color.White
            Closebutton.BackColor = Color.FromArgb(64, 64, 64)
            Closebutton.FlatStyle = FlatStyle.Flat
            Closebutton.ForeColor = Color.White
            Closebutton.FlatAppearance.BorderColor = Color.Gray
            UninstallButton.BackColor = Color.FromArgb(64, 64, 64)
            UninstallButton.FlatStyle = FlatStyle.Flat
            UninstallButton.ForeColor = Color.White
            UninstallButton.FlatAppearance.BorderColor = Color.Gray
            About.BackColor = Color.FromArgb(64, 64, 64)
            About.FlatStyle = FlatStyle.Flat
            About.ForeColor = Color.White
            About.FlatAppearance.BorderColor = Color.Gray
            Mode.BackColor = Color.FromArgb(64, 64, 64)
            Mode.FlatStyle = FlatStyle.Flat
            Mode.ForeColor = Color.White
            Mode.FlatAppearance.BorderColor = Color.Gray
            RichTextBox1.BackColor = Color.FromArgb(64, 64, 64)
            RichTextBox1.ForeColor = Color.White
        Else
            My.Settings.DarkModeOn = False
            Me.Close()
            Process.Start(exepath)
        End If
    End Sub
End Class
