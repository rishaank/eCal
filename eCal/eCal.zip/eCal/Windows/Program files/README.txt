eCal Overview
eCal is an easy to use GUI calculator. This is my first GUI application. This README will give you information on eCal. This application was made with Visual Studio using vb.net. The installer was made with Inno Setup.

Help
More information can be found on my website. Give feedback here. My GitHub website is here.
Installation
eCal is currently only supported on Windows but will make its way to other operating systems like MacOS.
1.	Download (save) the Windows-eCal-setup.exe (download from my GitHub page or my Website)
2.	Right-click on the file (after downloading it) and click properties
3.	Check the box that says unblock and click OK
4.	Run Windows-eCal-setup.exe and proceed with the steps on your screen


eCal v1.2 |Rishaan Kotian| README |Thank you for using eCal! 


