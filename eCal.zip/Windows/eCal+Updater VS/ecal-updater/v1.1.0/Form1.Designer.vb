﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ecalupdater
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ecalupdater))
        Me.Checkupdate = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Closebutton = New System.Windows.Forms.Button()
        Me.ecalexit = New System.Windows.Forms.Button()
        Me.ecallaunch = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.UninstallButton = New System.Windows.Forms.Button()
        Me.About = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Checkupdate
        '
        Me.Checkupdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Checkupdate.Location = New System.Drawing.Point(17, 145)
        Me.Checkupdate.Name = "Checkupdate"
        Me.Checkupdate.Size = New System.Drawing.Size(190, 52)
        Me.Checkupdate.TabIndex = 0
        Me.Checkupdate.Text = "Check for eCal updates"
        Me.Checkupdate.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.eCal_updater.My.Resources.Resources.eCal_download_icon
        Me.PictureBox1.Location = New System.Drawing.Point(23, 26)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(137, 113)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label1.Location = New System.Drawing.Point(166, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(292, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "eCal, the easiest calcultor to use"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(167, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(170, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Current Version: v2.1.0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(167, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(124, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Newest Version:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 133)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 20)
        Me.Label4.TabIndex = 5
        '
        'RichTextBox2
        '
        Me.RichTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.RichTextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.RichTextBox2.Location = New System.Drawing.Point(397, 64)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.ReadOnly = True
        Me.RichTextBox2.Size = New System.Drawing.Size(193, 70)
        Me.RichTextBox2.TabIndex = 7
        Me.RichTextBox2.Text = "Note: You require an internet connection to check for updates."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(368, 84)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 20)
        Me.Label5.TabIndex = 9
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipText = "eCal updater is running, right-click to close"
        Me.NotifyIcon1.BalloonTipTitle = "eCal updater"
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "eCal updater"
        Me.NotifyIcon1.Visible = True
        '
        'Closebutton
        '
        Me.Closebutton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Closebutton.Location = New System.Drawing.Point(473, 145)
        Me.Closebutton.Name = "Closebutton"
        Me.Closebutton.Size = New System.Drawing.Size(136, 52)
        Me.Closebutton.TabIndex = 12
        Me.Closebutton.Text = "Exit updater"
        Me.Closebutton.UseVisualStyleBackColor = True
        '
        'ecalexit
        '
        Me.ecalexit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ecalexit.Location = New System.Drawing.Point(213, 145)
        Me.ecalexit.Name = "ecalexit"
        Me.ecalexit.Size = New System.Drawing.Size(119, 52)
        Me.ecalexit.TabIndex = 13
        Me.ecalexit.Text = "Exit eCal"
        Me.ecalexit.UseVisualStyleBackColor = True
        '
        'ecallaunch
        '
        Me.ecallaunch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ecallaunch.Location = New System.Drawing.Point(340, 145)
        Me.ecallaunch.Name = "ecallaunch"
        Me.ecallaunch.Size = New System.Drawing.Size(127, 52)
        Me.ecallaunch.TabIndex = 14
        Me.ecallaunch.Text = "Launch eCal"
        Me.ecallaunch.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(22, 219)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(310, 52)
        Me.ProgressBar1.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(19, 285)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 20)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "Label6"
        '
        'UninstallButton
        '
        Me.UninstallButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UninstallButton.Location = New System.Drawing.Point(397, 219)
        Me.UninstallButton.Name = "UninstallButton"
        Me.UninstallButton.Size = New System.Drawing.Size(136, 52)
        Me.UninstallButton.TabIndex = 17
        Me.UninstallButton.Text = "Uninstall eCal"
        Me.UninstallButton.UseVisualStyleBackColor = True
        '
        'About
        '
        Me.About.Cursor = System.Windows.Forms.Cursors.Hand
        Me.About.Location = New System.Drawing.Point(397, 277)
        Me.About.Name = "About"
        Me.About.Size = New System.Drawing.Size(136, 52)
        Me.About.TabIndex = 18
        Me.About.Text = "About eCal updater"
        Me.About.UseVisualStyleBackColor = True
        '
        'ecalupdater
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(626, 359)
        Me.Controls.Add(Me.About)
        Me.Controls.Add(Me.UninstallButton)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.ecallaunch)
        Me.Controls.Add(Me.ecalexit)
        Me.Controls.Add(Me.Closebutton)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Checkupdate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ecalupdater"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "eCal updater"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Checkupdate As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents Closebutton As Button
    Friend WithEvents ecalexit As Button
    Friend WithEvents ecallaunch As Button
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents Label6 As Label
    Friend WithEvents UninstallButton As Button
    Friend WithEvents About As Button
End Class
