﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ecalupdater
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ecalupdater))
        Me.Checkupdate = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Closebutton = New System.Windows.Forms.Button()
        Me.ecalexit = New System.Windows.Forms.Button()
        Me.ecallaunch = New System.Windows.Forms.Button()
        Me.UninstallButton = New System.Windows.Forms.Button()
        Me.About = New System.Windows.Forms.Button()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.eCalvertext = New System.Windows.Forms.Label()
        Me.Latestvertext = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Mode = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Checkupdate
        '
        Me.Checkupdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Checkupdate.Location = New System.Drawing.Point(21, 158)
        Me.Checkupdate.Name = "Checkupdate"
        Me.Checkupdate.Size = New System.Drawing.Size(190, 52)
        Me.Checkupdate.TabIndex = 7
        Me.Checkupdate.Text = "Check for eCal updates"
        Me.Checkupdate.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label1.Location = New System.Drawing.Point(160, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(292, 25)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "eCal, the easiest calcultor to use"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(161, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(124, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Current Version:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(160, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(124, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Newest Version:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 133)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 20)
        Me.Label4.TabIndex = 5
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.Control
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.RichTextBox1.Location = New System.Drawing.Point(420, 67)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.Size = New System.Drawing.Size(173, 84)
        Me.RichTextBox1.TabIndex = 6
        Me.RichTextBox1.Text = "Note: You require an internet connection to check for updates."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(368, 84)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 20)
        Me.Label5.TabIndex = 9
        '
        'Closebutton
        '
        Me.Closebutton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Closebutton.Location = New System.Drawing.Point(477, 158)
        Me.Closebutton.Name = "Closebutton"
        Me.Closebutton.Size = New System.Drawing.Size(136, 52)
        Me.Closebutton.TabIndex = 10
        Me.Closebutton.Text = "Exit updater"
        Me.Closebutton.UseVisualStyleBackColor = True
        '
        'ecalexit
        '
        Me.ecalexit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ecalexit.Location = New System.Drawing.Point(217, 158)
        Me.ecalexit.Name = "ecalexit"
        Me.ecalexit.Size = New System.Drawing.Size(119, 52)
        Me.ecalexit.TabIndex = 8
        Me.ecalexit.Text = "Exit eCal"
        Me.ecalexit.UseVisualStyleBackColor = True
        '
        'ecallaunch
        '
        Me.ecallaunch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ecallaunch.Location = New System.Drawing.Point(344, 158)
        Me.ecallaunch.Name = "ecallaunch"
        Me.ecallaunch.Size = New System.Drawing.Size(127, 52)
        Me.ecallaunch.TabIndex = 9
        Me.ecallaunch.Text = "Launch eCal"
        Me.ecallaunch.UseVisualStyleBackColor = True
        '
        'UninstallButton
        '
        Me.UninstallButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UninstallButton.Location = New System.Drawing.Point(42, 225)
        Me.UninstallButton.Name = "UninstallButton"
        Me.UninstallButton.Size = New System.Drawing.Size(136, 52)
        Me.UninstallButton.TabIndex = 11
        Me.UninstallButton.Text = "Uninstall eCal"
        Me.UninstallButton.UseVisualStyleBackColor = True
        '
        'About
        '
        Me.About.Cursor = System.Windows.Forms.Cursors.Hand
        Me.About.Location = New System.Drawing.Point(201, 225)
        Me.About.Name = "About"
        Me.About.Size = New System.Drawing.Size(178, 52)
        Me.About.TabIndex = 12
        Me.About.Text = "About eCal updater"
        Me.About.UseVisualStyleBackColor = True
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "eCal Updater is running click to open. Double Click to close."
        Me.NotifyIcon1.Visible = True
        '
        'eCalvertext
        '
        Me.eCalvertext.AutoSize = True
        Me.eCalvertext.Location = New System.Drawing.Point(291, 69)
        Me.eCalvertext.Name = "eCalvertext"
        Me.eCalvertext.Size = New System.Drawing.Size(78, 20)
        Me.eCalvertext.TabIndex = 3
        Me.eCalvertext.Text = "Loading..."
        '
        'Latestvertext
        '
        Me.Latestvertext.AutoSize = True
        Me.Latestvertext.Location = New System.Drawing.Point(290, 104)
        Me.Latestvertext.Name = "Latestvertext"
        Me.Latestvertext.Size = New System.Drawing.Size(78, 20)
        Me.Latestvertext.TabIndex = 5
        Me.Latestvertext.Text = "Loading..."
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.ErrorImage = Global.eCal_updater.My.Resources.Resources.eCal_download_icon
        Me.PictureBox1.Image = Global.eCal_updater.My.Resources.Resources.eCal_download_icon
        Me.PictureBox1.InitialImage = Global.eCal_updater.My.Resources.Resources.eCal_download_icon
        Me.PictureBox1.Location = New System.Drawing.Point(18, 32)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(137, 113)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Mode
        '
        Me.Mode.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Mode.Location = New System.Drawing.Point(403, 225)
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(190, 52)
        Me.Mode.TabIndex = 13
        Me.Mode.Text = "Dark Mode: OFF"
        Me.Mode.UseVisualStyleBackColor = True
        '
        'ecalupdater
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(625, 288)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Mode)
        Me.Controls.Add(Me.Latestvertext)
        Me.Controls.Add(Me.eCalvertext)
        Me.Controls.Add(Me.About)
        Me.Controls.Add(Me.UninstallButton)
        Me.Controls.Add(Me.ecallaunch)
        Me.Controls.Add(Me.ecalexit)
        Me.Controls.Add(Me.Closebutton)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Checkupdate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ecalupdater"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "eCal updater"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Checkupdate As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Closebutton As Button
    Friend WithEvents ecalexit As Button
    Friend WithEvents ecallaunch As Button
    Friend WithEvents UninstallButton As Button
    Friend WithEvents About As Button
    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents eCalvertext As Label
    Friend WithEvents Latestvertext As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Mode As Button
End Class
