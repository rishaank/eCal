﻿Imports System.IO
Imports System.ComponentModel
Imports System.Net
Public Class ecalupdater
    Private Sub eCalupdater_FirstLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        'Showing warning that multiple instances are running
        multipleinstanceupdatercheck()
        'Show taskbar icon
        Dim contextmenu As New ContextMenu
        NotifyIcon1.ContextMenu = contextmenu
        Dim Exitbutton = contextmenu.MenuItems.Add("Exit")
        AddHandler Exitbutton.Click, AddressOf HandleClick
        'Kill eCal
        Dim proc As System.Diagnostics.Process
        Dim pList() As Process
        pList = Process.GetProcessesByName(“eCal”)
        For Each proc In pList
            proc.Kill()
        Next
        'Tutorial messagebox
        MessageBox.Show("Click Check for Updates to check for eCal updates. If the application tells you that you have an outdated version, click Update", "A Tutorial on How eCal installer works", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Dim user As String = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)

    Private Sub HandleClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Public Sub multipleinstanceupdatercheck()
        'Get number of instances of eCal updater
        If Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName).Length > 1 Then
            MessageBox.Show("Multiple instances of this program are running. eCal updater can not run with multiple instances of itself. eCal updater will close all instances of itself when you click OK. Relaunch the programm with only one instance of itself.", "Error, Multiple instances running", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Application.Exit()
        End If
    End Sub

    Private Sub Checkupdate_Click(sender As Object, e As EventArgs) Handles Checkupdate.Click
        Try
            Process.Start("https://rishaankotian.wixsite.com/home/v2-0-0")
        Catch ex As Exception
            MessageBox.Show("Sorry, an unknown error occured when updating. You can manually update by going to https://rishaankotian.wixsite.com/home/ecal and uninstalling this eCal version and installing that version.")
        End Try
    End Sub

    Private Sub Update_Click(sender As Object, e As EventArgs) Handles Update.Click
        Dim result As DialogResult = MessageBox.Show("You have clicked the 'Update' button. Do not click this button before you have clicked the 'Check for updates' button. Click the 'Check for Updates' button to check that you do have updates. Clicking cancel will close the application. Relaunch it again after clicking cancel if you click it. OK will proceed.", "WARNING", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If result = DialogResult.Cancel Then
            Me.Close()
        ElseIf result = DialogResult.OK Then
            Dim userdesktop As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
            If (System.IO.Directory.Exists(userdesktop & "\ecal-temp")) Then
                System.IO.Directory.Delete(userdesktop & "\ecal-temp", True)
            End If
            System.IO.Directory.CreateDirectory(userdesktop & "\ecal-temp")
            MessageBox.Show("eCal updates are available, eCal will update now. Note that eCal updater will freeze for a few seconds/minutes when downloading.", "eCal updater", MessageBoxButtons.OK)
            Using client As New WebClient
                'Note that the UI will freeze when downloading
                'Downloading setup.exe
                'Downloading setup.exe is to reinstall the latest eCal. I can do this because eCal currently doesn't save any settings, so reinstalling won't give a different experience than what is currently installed
                client.DownloadFile("https://drive.google.com/uc?id=1OHZumqIn1JnOqsVN2Y0kPMyc-JvAuY5-&export=download", userdesktop & "\ecal-temp\ecal-setup.exe")
            End Using
            MessageBox.Show("The file has finished downloading. The eCal updater will launch the uninstaller and new setup. Please proceed with the steps to uninstall eCal then proceed with the steps to install the new eCal.", "Finished Downloading")
            Dim result1 As DialogResult = MessageBox.Show("Have you downloaded eCal for all users or just for your user? Yes means you installed for all users. No means you installed just for your user. Cancel will close eCal updater.", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
            If result1 = DialogResult.Yes Then
                If (System.IO.Directory.Exists("C:\Program Files (x86)\eCal\unins000.exe")) Then
                    Process.Start("C:\Program Files (x86)\eCal\unins000.exe", AppWinStyle.NormalFocus)
                End If
            End If
            If result1 = DialogResult.No Then
                If (Not System.IO.Directory.Exists("C:\Program Files (x86)\eCal\unins000.exe")) Then
                    Process.Start(user & "\Programs\eCal\unins000.exe", AppWinStyle.NormalFocus)
                End If
            End If
            If result1 = DialogResult.Cancel Then
                Me.Close()
            End If
            Process.Start(userdesktop & "\ecal-temp\ecal-setup")
            Me.Close()
        End If
    End Sub

    Private Sub Closebutton_Click(sender As Object, e As EventArgs) Handles Closebutton.Click
        Me.Close()
    End Sub

    Private Sub ecalexit_Click(sender As Object, e As EventArgs) Handles ecalexit.Click
        Dim proc As System.Diagnostics.Process
        Dim pList() As Process
        pList = Process.GetProcessesByName(“eCal”)
        For Each proc In pList
            proc.Kill()
        Next
    End Sub

    Private Sub ecallaunch_Click(sender As Object, e As EventArgs) Handles ecallaunch.Click
        Dim result2 As DialogResult = MessageBox.Show("Select Yes if you installed for all users. Select No if you installed for just your user. Click Cancel to close eCal updater.", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
        If result2 = DialogResult.Yes Then
            Process.Start("C:\Program Files (x86)\eCal\eCal.exe")
        End If
        If result2 = DialogResult.No Then
            Process.Start(user & "\Programs\eCal\eCal.exe")
        End If
        If result2 = DialogResult.Cancel Then
            Me.Close()
        End If
    End Sub
End Class
