eCal Overview
eCal is an easy to use GUI calculator. This is my first GUI application. This README will give you information on eCal. This application was made with Visual Studio using vb.net. The installer was made with Inno Setup.

Help
More information can be found on my website. Give feedback here. My GitHub website is here.
Installation
eCal is currently only supported on Windows but will make its way to other operating systems like MacOS.
1.	First, go to the installation page here and download the Windows .zip file.
2.	If your browser or Windows says that the file is unsafe when downloading, and you trust eCal, you can ignore this.
3.	After downloading the .zip file, extract it, by right-clicking on it and clicking Extract all then extract.
4.	Right click on the setup.exe and click properties and check the box saying unblock and click OK.
5.	Run the installer and follow the steps on your screen to install eCal.


