﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class eCal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(eCal))
        Me.Num1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Num2 = New System.Windows.Forms.Button()
        Me.Addsign = New System.Windows.Forms.Button()
        Me.Equalsign = New System.Windows.Forms.Button()
        Me.Num0 = New System.Windows.Forms.Button()
        Me.Num3 = New System.Windows.Forms.Button()
        Me.Num4 = New System.Windows.Forms.Button()
        Me.Num5 = New System.Windows.Forms.Button()
        Me.Num6 = New System.Windows.Forms.Button()
        Me.Num7 = New System.Windows.Forms.Button()
        Me.Num8 = New System.Windows.Forms.Button()
        Me.Num9 = New System.Windows.Forms.Button()
        Me.Multiplysign = New System.Windows.Forms.Button()
        Me.Subtractsign = New System.Windows.Forms.Button()
        Me.Dividesign = New System.Windows.Forms.Button()
        Me.Allclear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Decimalsign = New System.Windows.Forms.Button()
        Me.Squaresign = New System.Windows.Forms.Button()
        Me.Sqrtsign = New System.Windows.Forms.Button()
        Me.Aboutbutton = New System.Windows.Forms.Button()
        Me.Updatecheck = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Num1
        '
        Me.Num1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num1.Location = New System.Drawing.Point(30, 394)
        Me.Num1.Name = "Num1"
        Me.Num1.Size = New System.Drawing.Size(75, 60)
        Me.Num1.TabIndex = 11
        Me.Num1.Text = "1"
        Me.Num1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!)
        Me.TextBox1.Location = New System.Drawing.Point(24, 31)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(414, 75)
        Me.TextBox1.TabIndex = 19
        '
        'Num2
        '
        Me.Num2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num2.Location = New System.Drawing.Point(140, 394)
        Me.Num2.Name = "Num2"
        Me.Num2.Size = New System.Drawing.Size(78, 60)
        Me.Num2.TabIndex = 12
        Me.Num2.Text = "2"
        Me.Num2.UseVisualStyleBackColor = True
        '
        'Addsign
        '
        Me.Addsign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Addsign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Addsign.Location = New System.Drawing.Point(358, 209)
        Me.Addsign.Name = "Addsign"
        Me.Addsign.Size = New System.Drawing.Size(78, 60)
        Me.Addsign.TabIndex = 6
        Me.Addsign.Text = "+"
        Me.Addsign.UseVisualStyleBackColor = True
        '
        'Equalsign
        '
        Me.Equalsign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Equalsign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Equalsign.Location = New System.Drawing.Point(256, 478)
        Me.Equalsign.Name = "Equalsign"
        Me.Equalsign.Size = New System.Drawing.Size(76, 60)
        Me.Equalsign.TabIndex = 17
        Me.Equalsign.Text = "="
        Me.Equalsign.UseVisualStyleBackColor = True
        '
        'Num0
        '
        Me.Num0.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num0.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num0.Location = New System.Drawing.Point(138, 478)
        Me.Num0.Name = "Num0"
        Me.Num0.Size = New System.Drawing.Size(78, 60)
        Me.Num0.TabIndex = 16
        Me.Num0.Text = "0"
        Me.Num0.UseVisualStyleBackColor = True
        '
        'Num3
        '
        Me.Num3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num3.Location = New System.Drawing.Point(255, 394)
        Me.Num3.Name = "Num3"
        Me.Num3.Size = New System.Drawing.Size(78, 60)
        Me.Num3.TabIndex = 13
        Me.Num3.Text = "3"
        Me.Num3.UseVisualStyleBackColor = True
        '
        'Num4
        '
        Me.Num4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num4.Location = New System.Drawing.Point(26, 302)
        Me.Num4.Name = "Num4"
        Me.Num4.Size = New System.Drawing.Size(78, 60)
        Me.Num4.TabIndex = 7
        Me.Num4.Text = "4"
        Me.Num4.UseVisualStyleBackColor = True
        '
        'Num5
        '
        Me.Num5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num5.Location = New System.Drawing.Point(140, 302)
        Me.Num5.Name = "Num5"
        Me.Num5.Size = New System.Drawing.Size(78, 60)
        Me.Num5.TabIndex = 8
        Me.Num5.Text = "5"
        Me.Num5.UseVisualStyleBackColor = True
        '
        'Num6
        '
        Me.Num6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num6.Location = New System.Drawing.Point(254, 302)
        Me.Num6.Name = "Num6"
        Me.Num6.Size = New System.Drawing.Size(78, 60)
        Me.Num6.TabIndex = 9
        Me.Num6.Text = "6"
        Me.Num6.UseVisualStyleBackColor = True
        '
        'Num7
        '
        Me.Num7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num7.Location = New System.Drawing.Point(24, 209)
        Me.Num7.Name = "Num7"
        Me.Num7.Size = New System.Drawing.Size(78, 60)
        Me.Num7.TabIndex = 3
        Me.Num7.Text = "7"
        Me.Num7.UseVisualStyleBackColor = True
        '
        'Num8
        '
        Me.Num8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num8.Location = New System.Drawing.Point(140, 209)
        Me.Num8.Name = "Num8"
        Me.Num8.Size = New System.Drawing.Size(78, 60)
        Me.Num8.TabIndex = 4
        Me.Num8.Text = "8"
        Me.Num8.UseVisualStyleBackColor = True
        '
        'Num9
        '
        Me.Num9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Num9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Num9.Location = New System.Drawing.Point(254, 209)
        Me.Num9.Name = "Num9"
        Me.Num9.Size = New System.Drawing.Size(78, 60)
        Me.Num9.TabIndex = 5
        Me.Num9.Text = "9"
        Me.Num9.UseVisualStyleBackColor = True
        '
        'Multiplysign
        '
        Me.Multiplysign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Multiplysign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Multiplysign.Location = New System.Drawing.Point(358, 394)
        Me.Multiplysign.Name = "Multiplysign"
        Me.Multiplysign.Size = New System.Drawing.Size(78, 60)
        Me.Multiplysign.TabIndex = 14
        Me.Multiplysign.Text = "x"
        Me.Multiplysign.UseVisualStyleBackColor = True
        '
        'Subtractsign
        '
        Me.Subtractsign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Subtractsign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Subtractsign.Location = New System.Drawing.Point(358, 302)
        Me.Subtractsign.Name = "Subtractsign"
        Me.Subtractsign.Size = New System.Drawing.Size(78, 63)
        Me.Subtractsign.TabIndex = 10
        Me.Subtractsign.Text = "-"
        Me.Subtractsign.UseVisualStyleBackColor = True
        '
        'Dividesign
        '
        Me.Dividesign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Dividesign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Dividesign.Location = New System.Drawing.Point(358, 478)
        Me.Dividesign.Name = "Dividesign"
        Me.Dividesign.Size = New System.Drawing.Size(78, 60)
        Me.Dividesign.TabIndex = 18
        Me.Dividesign.Text = "÷"
        Me.Dividesign.UseVisualStyleBackColor = True
        '
        'Allclear
        '
        Me.Allclear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Allclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Allclear.Location = New System.Drawing.Point(24, 123)
        Me.Allclear.Name = "Allclear"
        Me.Allclear.Size = New System.Drawing.Size(194, 60)
        Me.Allclear.TabIndex = 0
        Me.Allclear.Text = "AC"
        Me.Allclear.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 20)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Label1"
        '
        'Decimalsign
        '
        Me.Decimalsign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Decimalsign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Decimalsign.Location = New System.Drawing.Point(30, 480)
        Me.Decimalsign.Name = "Decimalsign"
        Me.Decimalsign.Size = New System.Drawing.Size(75, 60)
        Me.Decimalsign.TabIndex = 15
        Me.Decimalsign.Text = "."
        Me.Decimalsign.UseVisualStyleBackColor = True
        '
        'Squaresign
        '
        Me.Squaresign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Squaresign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Squaresign.Location = New System.Drawing.Point(256, 123)
        Me.Squaresign.Name = "Squaresign"
        Me.Squaresign.Size = New System.Drawing.Size(78, 60)
        Me.Squaresign.TabIndex = 1
        Me.Squaresign.Text = "x²"
        Me.Squaresign.UseVisualStyleBackColor = True
        '
        'Sqrtsign
        '
        Me.Sqrtsign.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Sqrtsign.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Sqrtsign.Location = New System.Drawing.Point(358, 123)
        Me.Sqrtsign.Name = "Sqrtsign"
        Me.Sqrtsign.Size = New System.Drawing.Size(78, 60)
        Me.Sqrtsign.TabIndex = 2
        Me.Sqrtsign.Text = "√"
        Me.Sqrtsign.UseVisualStyleBackColor = True
        '
        'Aboutbutton
        '
        Me.Aboutbutton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Aboutbutton.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Aboutbutton.Location = New System.Drawing.Point(30, 549)
        Me.Aboutbutton.Name = "Aboutbutton"
        Me.Aboutbutton.Size = New System.Drawing.Size(406, 46)
        Me.Aboutbutton.TabIndex = 21
        Me.Aboutbutton.Text = "About"
        Me.Aboutbutton.UseVisualStyleBackColor = True
        '
        'Updatecheck
        '
        Me.Updatecheck.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Updatecheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Updatecheck.Location = New System.Drawing.Point(26, 611)
        Me.Updatecheck.Name = "Updatecheck"
        Me.Updatecheck.Size = New System.Drawing.Size(406, 46)
        Me.Updatecheck.TabIndex = 22
        Me.Updatecheck.Text = "Check for eCal Updates"
        Me.Updatecheck.UseVisualStyleBackColor = True
        '
        'eCal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(461, 666)
        Me.Controls.Add(Me.Updatecheck)
        Me.Controls.Add(Me.Aboutbutton)
        Me.Controls.Add(Me.Sqrtsign)
        Me.Controls.Add(Me.Squaresign)
        Me.Controls.Add(Me.Decimalsign)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Allclear)
        Me.Controls.Add(Me.Dividesign)
        Me.Controls.Add(Me.Subtractsign)
        Me.Controls.Add(Me.Multiplysign)
        Me.Controls.Add(Me.Num9)
        Me.Controls.Add(Me.Num8)
        Me.Controls.Add(Me.Num7)
        Me.Controls.Add(Me.Num6)
        Me.Controls.Add(Me.Num5)
        Me.Controls.Add(Me.Num4)
        Me.Controls.Add(Me.Num3)
        Me.Controls.Add(Me.Num0)
        Me.Controls.Add(Me.Equalsign)
        Me.Controls.Add(Me.Addsign)
        Me.Controls.Add(Me.Num2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Num1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "eCal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "eCal"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Num1 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Num2 As Button
    Friend WithEvents Addsign As Button
    Friend WithEvents Equalsign As Button
    Friend WithEvents Num0 As Button
    Friend WithEvents Num3 As Button
    Friend WithEvents Num4 As Button
    Friend WithEvents Num5 As Button
    Friend WithEvents Num6 As Button
    Friend WithEvents Num7 As Button
    Friend WithEvents Num8 As Button
    Friend WithEvents Num9 As Button
    Friend WithEvents Multiplysign As Button
    Friend WithEvents Subtractsign As Button
    Friend WithEvents Dividesign As Button
    Friend WithEvents Allclear As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Decimalsign As Button
    Friend WithEvents Squaresign As Button
    Friend WithEvents Sqrtsign As Button
    Friend WithEvents Aboutbutton As Button
    Friend WithEvents Updatecheck As Button
End Class
