﻿Imports System.IO
Imports System.ComponentModel
Imports System.Net
Public Class ecalupdater
    Public Sub eCalupdater_FirstLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        'Showing warning that multiple instances are running
        multipleinstanceupdatercheck()
        'Show taskbar icon
        Dim contextmenu As New ContextMenu
        NotifyIcon1.ContextMenu = contextmenu
        Dim Exitbutton = contextmenu.MenuItems.Add("Exit")
        AddHandler Exitbutton.Click, AddressOf HandleClick
        'Kill eCal
        Dim proc As System.Diagnostics.Process
        Dim pList() As Process
        pList = Process.GetProcessesByName(“eCal”)
        For Each proc In pList
            proc.Kill()
        Next
    End Sub
    Dim result As Integer = userinstall()
    Public Function userinstall()
        Dim question As DialogResult = MessageBox.Show("Did you install for all users? Yes means you installed for all users. No means You installed for a single user.", "", MessageBoxButtons.YesNo)
        If question = DialogResult.Yes Then
            Return 1
            '1 means install for all users
        ElseIf question = DialogResult.No Then
            Return 2
            '2 means install for single user
        End If
        Return 0
    End Function
    'user app data location as variable
    Dim userappdata As String = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
    'Makes the toolbar icon work
    Private Sub HandleClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
            Me.Close()
        End Sub
    'checks for multiple instances of updater
    Public Sub multipleinstanceupdatercheck()
        'Get number of instances of eCal updater
        If Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName).Length > 1 Then
            'Shows error box
            MessageBox.Show("Multiple instances of this program are running. eCal updater can not run with multiple instances of itself. eCal updater will close all instances of itself when you click OK. Relaunch the programm with only one instance of itself.", "Error, Multiple instances running", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            'Closes application
            Me.Close()
        End If
    End Sub
    'Creates a variable to user's documents folder
    Dim userdocuments As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
    Private Sub Checkupdate_Click(sender As Object, e As EventArgs) Handles Checkupdate.Click
        Dim wb As New WebClient
        Dim wbhtml As String = wb.DownloadString("https://rishaankotian.wixsite.com/home/v2-1-0")
        'To know if string "Newest" is inside website
        Dim StringContain As Boolean = wbhtml.Contains("Newest")
        'Checks if website has "Newest"
        If StringContain = True Then
            'Shows message
            MessageBox.Show("eCal is up-to-date. You are running version v2.1.0.", "No updates found", MessageBoxButtons.OK)
            'If ecal is not up to date (updating code)
        ElseIf StringContain = False Then
            Dim answer1 As DialogResult = MessageBox.Show("Updates are available. Would you like to install them now? Yes installs updates. No closes eCal updater.", "Updates Found", MessageBoxButtons.YesNo)
            'Asking if user wants to update
            If answer1 = DialogResult.Yes Then
                If (System.IO.Directory.Exists(userdocuments & "\ecal-temp")) Then
                    System.IO.Directory.Delete(userdocuments & "\ecal-temp", True)
                End If
                System.IO.Directory.CreateDirectory(userdocuments & "\ecal-temp")
                Using client As New WebClient
                    'Downloading setup.exe
                    'Downloading setup.exe Is to reinstall the latest eCal. I can do this because eCal currently doesn't save any settings, so reinstalling won't give a different experience than what is currently installed
                    ProgressBar1.Value = "30"
                    Label6.Text = "Downloading the latest setup.exe from server (Application might freeze)"
                    client.DownloadFile("https://drive.google.com/uc?id=1OHZumqIn1JnOqsVN2Y0kPMyc-JvAuY5-&export=download", userdocuments & "\ecal-temp\ecal-setup.exe")
                End Using
                Me.Close()
                'Uninstalling eCal depending on if installed for all users or not
                If result = 1 Then
                    Dim pHelp As New ProcessStartInfo
                    pHelp.FileName = "C:\Program Files (x86)\eCal\unins000.exe"
                    pHelp.Arguments = "/VERYSILENT"
                    pHelp.UseShellExecute = True
                    pHelp.WindowStyle = ProcessWindowStyle.Normal
                    Dim proc As Process = Process.Start(pHelp)
                ElseIf result = 2 Then
                    Dim pHelp4 As New ProcessStartInfo
                    pHelp4.FileName = userappdata & "\Programs\eCal\unins000.exe"
                    pHelp4.Arguments = "/VERYSILENT"
                    pHelp4.UseShellExecute = True
                    pHelp4.WindowStyle = ProcessWindowStyle.Normal
                    Dim proc4 As Process = Process.Start(pHelp4)
                End If
                'Installing newer version
                Dim pHelp2 As New ProcessStartInfo
                pHelp2.FileName = userdocuments & "/ecal-temp/ecal-setup.exe"
                pHelp2.Arguments = "/SILENT"
                pHelp2.UseShellExecute = True
                pHelp2.WindowStyle = ProcessWindowStyle.Normal
                ProgressBar1.Value = "100"
                Label6.Text = "Asking User If User wants to update for all users or for single user"
                Dim proc2 As Process = Process.Start(pHelp2)
            ElseIf answer1 = DialogResult.No Then
                Me.Close()
            End If
        End If
    End Sub

    Private Sub Closebutton_Click(sender As Object, e As EventArgs) Handles Closebutton.Click
            Me.Close()
        End Sub

        Private Sub ecalexit_Click(sender As Object, e As EventArgs) Handles ecalexit.Click
        Dim proc3 As System.Diagnostics.Process
        Dim pList() As Process
            pList = Process.GetProcessesByName(“eCal”)
        For Each proc3 In pList
            proc3.Kill()
        Next
    End Sub

        Private Sub ecallaunch_Click(sender As Object, e As EventArgs) Handles ecallaunch.Click
        If result = 1 Then
            Process.Start("C:\Program Files (x86)\eCal\eCal.exe")
        End If
        If result = 2 Then
            Process.Start(userappdata & "\Programs\eCal\eCal.exe")
        End If
    End Sub

    Private Sub UninstallButton_Click(sender As Object, e As EventArgs) Handles UninstallButton.Click
        If result = 1 Then
            Dim pHelp As New ProcessStartInfo
            pHelp.FileName = "C:\Program Files (x86)\eCal\unins000.exe"
            pHelp.Arguments = "/VERYSILENT"
            pHelp.UseShellExecute = True
            pHelp.WindowStyle = ProcessWindowStyle.Normal
            Me.Close()
            Dim proc As Process = Process.Start(pHelp)
        ElseIf result = 2 Then
            Dim pHelp4 As New ProcessStartInfo
            pHelp4.FileName = userappdata & "\Programs\eCal\unins000.exe"
            pHelp4.Arguments = "/VERYSILENT"
            pHelp4.UseShellExecute = True
            pHelp4.WindowStyle = ProcessWindowStyle.Normal
            Me.Close()
            Dim proc4 As Process = Process.Start(pHelp4)
        End If
    End Sub

    Private Sub About_Click(sender As Object, e As EventArgs) Handles About.Click
        MessageBox.Show("eCal updater v1.1.0 |  eCal v2.1.0 | eCal updater updates eCal. Click Check for updates to check for updates. There will be a tray icon indicating that eCal updater is open. Made by Rishaan Kotian, a 10 year old programmer. Made with Visual Studio using VB.NET. Thank you for supporting eCal. More info in README and on the eCal webiste and GitHub websites.", "About eCal updater", MessageBoxButtons.OK)
    End Sub
End Class
