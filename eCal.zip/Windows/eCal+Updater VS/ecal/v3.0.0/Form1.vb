﻿Imports System.IO
Imports System.ComponentModel
Imports System.Net
Public Class eCal
    Dim IntVal As Double

    ' LastCmd Cmd
    '1 = addition
    '2 = subtraction
    '3 = multiplication
    '4 = division

    Dim LastCmd As Double
    Dim exepath As String = Application.ExecutablePath
    Dim userappdata As String = (Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) & "\Programs")
    Dim version As String = Application.ProductVersion

    Private Sub eCal_FirstLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        MaximizeBox = False
        My.Settings.Upgrade()
        If My.Settings.Darkmodeon = True Then
            Mode.Text = "Dark Mode: ON"
            TextBox1.BackColor = Color.FromArgb(64, 64, 64)
            TextBox1.ForeColor = Color.White
            MyBase.BackColor = Color.FromArgb(64, 64, 64)
            Allclear.BackColor = Color.FromArgb(64, 64, 64)
            Allclear.FlatStyle = FlatStyle.Flat
            Allclear.ForeColor = Color.White
            Allclear.FlatAppearance.BorderColor = Color.Gray
            Squaresign.BackColor = Color.FromArgb(64, 64, 64)
            Squaresign.FlatStyle = FlatStyle.Flat
            Squaresign.ForeColor = Color.White
            Squaresign.FlatAppearance.BorderColor = Color.Gray
            Sqrtsign.BackColor = Color.FromArgb(64, 64, 64)
            Sqrtsign.FlatStyle = FlatStyle.Flat
            Sqrtsign.ForeColor = Color.White
            Sqrtsign.FlatAppearance.BorderColor = Color.Gray
            Backspace.BackColor = Color.FromArgb(64, 64, 64)
            Backspace.FlatStyle = FlatStyle.Flat
            Backspace.ForeColor = Color.White
            Backspace.FlatAppearance.BorderColor = Color.Gray
            Num7.BackColor = Color.FromArgb(64, 64, 64)
            Num7.FlatStyle = FlatStyle.Flat
            Num7.ForeColor = Color.White
            Num7.FlatAppearance.BorderColor = Color.Gray
            Num8.BackColor = Color.FromArgb(64, 64, 64)
            Num8.FlatStyle = FlatStyle.Flat
            Num8.ForeColor = Color.White
            Num8.FlatAppearance.BorderColor = Color.Gray
            Num9.BackColor = Color.FromArgb(64, 64, 64)
            Num9.FlatStyle = FlatStyle.Flat
            Num9.ForeColor = Color.White
            Num9.FlatAppearance.BorderColor = Color.Gray
            Num4.BackColor = Color.FromArgb(64, 64, 64)
            Num4.FlatStyle = FlatStyle.Flat
            Num4.ForeColor = Color.White
            Num4.FlatAppearance.BorderColor = Color.Gray
            Num5.BackColor = Color.FromArgb(64, 64, 64)
            Num5.FlatStyle = FlatStyle.Flat
            Num5.ForeColor = Color.White
            Num5.FlatAppearance.BorderColor = Color.Gray
            Num6.BackColor = Color.FromArgb(64, 64, 64)
            Num6.FlatStyle = FlatStyle.Flat
            Num6.ForeColor = Color.White
            Num6.FlatAppearance.BorderColor = Color.Gray
            Num1.BackColor = Color.FromArgb(64, 64, 64)
            Num1.FlatStyle = FlatStyle.Flat
            Num1.ForeColor = Color.White
            Num1.FlatAppearance.BorderColor = Color.Gray
            Num2.BackColor = Color.FromArgb(64, 64, 64)
            Num2.FlatStyle = FlatStyle.Flat
            Num2.ForeColor = Color.White
            Num2.FlatAppearance.BorderColor = Color.Gray
            Num3.BackColor = Color.FromArgb(64, 64, 64)
            Num3.FlatStyle = FlatStyle.Flat
            Num3.ForeColor = Color.White
            Num3.FlatAppearance.BorderColor = Color.Gray
            Num0.BackColor = Color.FromArgb(64, 64, 64)
            Num0.FlatStyle = FlatStyle.Flat
            Num0.ForeColor = Color.White
            Num0.FlatAppearance.BorderColor = Color.Gray
            Multiplysign.BackColor = Color.FromArgb(64, 64, 64)
            Multiplysign.FlatStyle = FlatStyle.Flat
            Multiplysign.ForeColor = Color.White
            Multiplysign.FlatAppearance.BorderColor = Color.Gray
            Dividesign.BackColor = Color.FromArgb(64, 64, 64)
            Dividesign.FlatStyle = FlatStyle.Flat
            Dividesign.ForeColor = Color.White
            Dividesign.FlatAppearance.BorderColor = Color.Gray
            Addsign.BackColor = Color.FromArgb(64, 64, 64)
            Addsign.FlatStyle = FlatStyle.Flat
            Addsign.ForeColor = Color.White
            Addsign.FlatAppearance.BorderColor = Color.Gray
            Subtractsign.BackColor = Color.FromArgb(64, 64, 64)
            Subtractsign.FlatStyle = FlatStyle.Flat
            Subtractsign.ForeColor = Color.White
            Subtractsign.FlatAppearance.BorderColor = Color.Gray
            Decimalsign.BackColor = Color.FromArgb(64, 64, 64)
            Decimalsign.FlatStyle = FlatStyle.Flat
            Decimalsign.ForeColor = Color.White
            Decimalsign.FlatAppearance.BorderColor = Color.Gray
            Equalsign.BackColor = Color.FromArgb(64, 64, 64)
            Equalsign.FlatStyle = FlatStyle.Flat
            Equalsign.ForeColor = Color.White
            Equalsign.FlatAppearance.BorderColor = Color.Gray
            Updatecheck.BackColor = Color.FromArgb(64, 64, 64)
            Updatecheck.FlatStyle = FlatStyle.Flat
            Updatecheck.ForeColor = Color.White
            Updatecheck.FlatAppearance.BorderColor = Color.Gray
            Aboutbutton.BackColor = Color.FromArgb(64, 64, 64)
            Aboutbutton.FlatStyle = FlatStyle.Flat
            Aboutbutton.ForeColor = Color.White
            Aboutbutton.FlatAppearance.BorderColor = Color.Gray
            Mode.BackColor = Color.FromArgb(64, 64, 64)
            Mode.FlatStyle = FlatStyle.Flat
            Mode.ForeColor = Color.White
            Mode.FlatAppearance.BorderColor = Color.Gray
            AutoUpdate.BackColor = Color.FromArgb(64, 64, 64)
            AutoUpdate.FlatStyle = FlatStyle.Flat
            AutoUpdate.ForeColor = Color.White
            AutoUpdate.FlatAppearance.BorderColor = Color.Gray
            Label1.ForeColor = Color.White
        End If
        TextBox1.Text = 0
        IntVal = 0
        LastCmd = 0
        Label1.Text = ""
        If Not My.Settings.Textbox1 = "0" Then
            TextBox1.Text = My.Settings.Textbox1
        End If
        If Not My.Settings.Label1 = "0" Then
            Label1.Text = My.Settings.Label1
        End If
        If Not My.Settings.IntVal = 0 Then
            IntVal = My.Settings.IntVal
        End If
        If Not My.Settings.LastCmd = 0 Then
            LastCmd = My.Settings.LastCmd
        End If
        If System.IO.Directory.Exists(userdocuments & "\ecal-temp") Then
            System.IO.Directory.Delete(userdocuments & "\ecal-temp", True)
        End If
        If My.Settings.AutoUpdateON = True Then
            Dim wb As New WebClient
            Dim wbhtml As String = wb.DownloadString("https://rishaankotian.wixsite.com/home/v3-0-0")
            Dim StringContain As Boolean = wbhtml.Contains("Newest")
            'Checks if website has "Newest"
            If (StringContain = False) Then
                MessageBox.Show("eCal has a new update. To update eCal, click check for updates", "Updates available", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            AutoUpdate.Text = "Auto Update: OFF"
        End If
    End Sub

    Private Sub SessionSave(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        e.Cancel = False
        My.Settings.Textbox1 = (TextBox1.Text.ToString)
        My.Settings.Label1 = (Label1.Text.ToString)
        My.Settings.IntVal = IntVal
        My.Settings.LastCmd = LastCmd
    End Sub

    Dim userdocuments As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)

    Private Sub Textbox1_Key(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Updatecheck_Key(sender As Object, e As KeyPressEventArgs) Handles Updatecheck.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Mode_Key(sender As Object, e As KeyPressEventArgs) Handles Mode.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Aboutbutton_Key(sender As Object, e As KeyPressEventArgs) Handles Aboutbutton.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Equalsign_Key(sender As Object, e As KeyPressEventArgs) Handles Equalsign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Multiplysign_Key(sender As Object, e As KeyPressEventArgs) Handles Multiplysign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Dividesign_Key(sender As Object, e As KeyPressEventArgs) Handles Dividesign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Ddecimalsign_Key(sender As Object, e As KeyPressEventArgs) Handles Decimalsign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Subtractsign_Key(sender As Object, e As KeyPressEventArgs) Handles Subtractsign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Addsign_Key(sender As Object, e As KeyPressEventArgs) Handles Addsign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Backspace_Key(sender As Object, e As KeyPressEventArgs) Handles Backspace.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Sqrtsign_Key(sender As Object, e As KeyPressEventArgs) Handles Sqrtsign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Squaresign_Key(sender As Object, e As KeyPressEventArgs) Handles Squaresign.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Allclear_Key(sender As Object, e As KeyPressEventArgs) Handles Allclear.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num9_Key(sender As Object, e As KeyPressEventArgs) Handles Num9.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num8_Key(sender As Object, e As KeyPressEventArgs) Handles Num8.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num7_Key(sender As Object, e As KeyPressEventArgs) Handles Num7.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num6_Key(sender As Object, e As KeyPressEventArgs) Handles Num6.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num5_Key(sender As Object, e As KeyPressEventArgs) Handles Num5.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num4_Key(sender As Object, e As KeyPressEventArgs) Handles Num4.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num3_Key(sender As Object, e As KeyPressEventArgs) Handles Num3.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num2_Key(sender As Object, e As KeyPressEventArgs) Handles Num2.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num1_Key(sender As Object, e As KeyPressEventArgs) Handles Num1.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num0_Key(sender As Object, e As KeyPressEventArgs) Handles Num0.KeyPress
        If Asc(e.KeyChar) = 48 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("0")

            Else
                TextBox1.AppendText("0")

            End If
        End If
        If Asc(e.KeyChar) = 49 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("1")

            Else
                TextBox1.AppendText("1")

            End If
        End If
        If Asc(e.KeyChar) = 50 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("2")

            Else
                TextBox1.AppendText("2")

            End If
        End If
        If Asc(e.KeyChar) = 51 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("3")

            Else
                TextBox1.AppendText("3")

            End If
        End If
        If Asc(e.KeyChar) = 52 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("4")

            Else
                TextBox1.AppendText("4")

            End If
        End If
        If Asc(e.KeyChar) = 53 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("5")

            Else
                TextBox1.AppendText("5")

            End If
        End If
        If Asc(e.KeyChar) = 54 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("6")

            Else
                TextBox1.AppendText("6")

            End If
        End If
        If Asc(e.KeyChar) = 55 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("7")

            Else
                TextBox1.AppendText("7")

            End If
        End If
        If Asc(e.KeyChar) = 56 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("8")

            Else
                TextBox1.AppendText("8")

            End If
        End If
        If Asc(e.KeyChar) = 57 Then
            If CDbl(TextBox1.Text) = 0 Then
                TextBox1.Text = ("9")

            Else
                TextBox1.AppendText("9")

            End If
        End If
        If Asc(e.KeyChar) = 8 Then
            If TextBox1.Text.Length <> 1 Or 0 Then
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
            ElseIf TextBox1.Text.Length = 1 Then
                TextBox1.Text = "0"
            End If
        End If
        If Asc(e.KeyChar) = 43 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal + CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 1
        End If
        If Asc(e.KeyChar) = 45 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal - CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 2
        End If
        If Asc(e.KeyChar) = 120 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 88 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 42 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal * CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 3
        End If
        If Asc(e.KeyChar) = 47 Then
            If IntVal = 0 Then
                IntVal = CDbl(TextBox1.Text)
            Else
                IntVal = IntVal / CDbl(TextBox1.Text)
            End If
            TextBox1.Text = 0
            Label1.Text = IntVal
            LastCmd = 4
        End If
        If Asc(e.KeyChar) = 46 Then
            TextBox1.AppendText(".")
        End If
        If Asc(e.KeyChar) = 61 Then
            If LastCmd = 1 Then
                TextBox1.Text = IntVal + TextBox1.Text
            ElseIf LastCmd = 2 Then
                TextBox1.Text = IntVal - TextBox1.Text
            ElseIf LastCmd = 3 Then
                TextBox1.Text = IntVal * TextBox1.Text
            ElseIf LastCmd = 4 Then
                TextBox1.Text = IntVal / TextBox1.Text
            End If
        End If
    End Sub

    Private Sub Num0_Click(sender As Object, e As EventArgs) Handles Num0.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("0")

        Else
            TextBox1.AppendText("0")

        End If
    End Sub

    Private Sub Num1_Click(sender As Object, e As EventArgs) Handles Num1.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("1")

        Else
            TextBox1.AppendText("1")

        End If
    End Sub

    Private Sub Num2_Click(sender As Object, e As EventArgs) Handles Num2.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("2")

        Else
            TextBox1.AppendText("2")

        End If
    End Sub

    Private Sub Num3_Click(sender As Object, e As EventArgs) Handles Num3.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("3")

        Else
            TextBox1.AppendText("3")

        End If
    End Sub

    Private Sub Num4_Click(sender As Object, e As EventArgs) Handles Num4.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("4")

        Else
            TextBox1.AppendText("1")

        End If
    End Sub

    Private Sub Num5_Click(sender As Object, e As EventArgs) Handles Num5.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("5")

        Else
            TextBox1.AppendText("5")

        End If
    End Sub

    Private Sub Num6_Click(sender As Object, e As EventArgs) Handles Num6.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("6")

        Else
            TextBox1.AppendText("6")

        End If
    End Sub

    Private Sub Num7_Click(sender As Object, e As EventArgs) Handles Num7.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("7")

        Else
            TextBox1.AppendText("7")

        End If
    End Sub

    Private Sub Num8_Click(sender As Object, e As EventArgs) Handles Num8.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("8")

        Else
            TextBox1.AppendText("8")

        End If
    End Sub

    Private Sub Num9_Click(sender As Object, e As EventArgs) Handles Num9.Click
        If CDbl(TextBox1.Text) = 0 Then
            TextBox1.Text = ("9")

        Else
            TextBox1.AppendText("9")

        End If
    End Sub

    Private Sub Decimalsign_Click(sender As Object, e As EventArgs) Handles Decimalsign.Click
        TextBox1.AppendText(".")
    End Sub

    Private Sub Addsign_Click(sender As Object, e As EventArgs) Handles Addsign.Click
        If IntVal = 0 Then
            IntVal = CDbl(TextBox1.Text)
        Else
            IntVal = IntVal + CDbl(TextBox1.Text)
        End If
        TextBox1.Text = 0
        Label1.Text = IntVal
        LastCmd = 1
    End Sub

    Private Sub Subtractsign_Click(sender As Object, e As EventArgs) Handles Subtractsign.Click
        If IntVal = 0 Then
            IntVal = CDbl(TextBox1.Text)
        Else
            IntVal = IntVal - CDbl(TextBox1.Text)
        End If
        TextBox1.Text = 0
        Label1.Text = IntVal
        LastCmd = 2
    End Sub

    Private Sub Multiplysign_Click(sender As Object, e As EventArgs) Handles Multiplysign.Click
        If IntVal = 0 Then
            IntVal = CDbl(TextBox1.Text)
        Else
            IntVal = IntVal * CDbl(TextBox1.Text)
        End If
        TextBox1.Text = 0
        Label1.Text = IntVal
        LastCmd = 3
    End Sub

    Private Sub Dividesign_Click(sender As Object, e As EventArgs) Handles Dividesign.Click
        If IntVal = 0 Then
            IntVal = CDbl(TextBox1.Text)
        Else
            IntVal = IntVal / CDbl(TextBox1.Text)
        End If
        TextBox1.Text = 0
        Label1.Text = IntVal
        LastCmd = 4
    End Sub

    Private Sub Sqrtsign_Click(sender As Object, e As EventArgs) Handles Sqrtsign.Click
        TextBox1.Text = Math.Sqrt(CDbl(TextBox1.Text))
    End Sub

    Private Sub Squaresign_Click(sender As Object, e As EventArgs) Handles Squaresign.Click
        TextBox1.Text = CDbl(TextBox1.Text) * CDbl(TextBox1.Text)
    End Sub

    Private Sub Equalsign_Click(sender As Object, e As EventArgs) Handles Equalsign.Click
        If LastCmd = 1 Then
            TextBox1.Text = IntVal + TextBox1.Text
        ElseIf LastCmd = 2 Then
            TextBox1.Text = IntVal - TextBox1.Text
        ElseIf LastCmd = 3 Then
            TextBox1.Text = IntVal * TextBox1.Text
        ElseIf LastCmd = 4 Then
            TextBox1.Text = IntVal / TextBox1.Text
        End If
    End Sub

    Private Sub Allclear_Click(sender As Object, e As EventArgs) Handles Allclear.Click
        TextBox1.Text = 0
        IntVal = 0
        LastCmd = 0
        Label1.Text = ""
    End Sub

    Private Sub Aboutbutton_Click(sender As Object, e As EventArgs) Handles Aboutbutton.Click
        MessageBox.Show("eCal version: " & version & vbNewLine & "Developer: Rishaan Kotian (10 years old)" & vbNewLine & "Main Website: https://rishaankotian.wixsite.com/home/ecal" & vbNewLine & "GitHub: https://github.com/rishaank/eCal" & vbNewLine & "Feedback: https://docs.google.com/forms/d/e/1FAIpQLSfgiyL7RUH8CC_7mPTITcIBk7X_-jNWP258FcexjQ426rDfQA/viewform" & vbNewLine & "Thank you for supporting and using eCal!", "About eCal", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub Updatecheck_Click(sender As Object, e As EventArgs) Handles Updatecheck.Click
        If (exepath.Contains("C:\Program Files (x86)")) Then
            Process.Start("C:\Program Files (x86)\eCal\eCal-updater.exe")
        Else
            Process.Start(userappdata & "\eCal\eCal-updater.exe")
        End If
    End Sub

    Private Sub Mode_Click(sender As Object, e As EventArgs) Handles Mode.Click
        If My.Settings.Darkmodeon = False Then
            My.Settings.Darkmodeon = True
            Mode.Text = "Dark Mode: ON"
            TextBox1.BackColor = Color.FromArgb(64, 64, 64)
            TextBox1.ForeColor = Color.White
            MyBase.BackColor = Color.FromArgb(64, 64, 64)
            Allclear.BackColor = Color.FromArgb(64, 64, 64)
            Allclear.FlatStyle = FlatStyle.Flat
            Allclear.ForeColor = Color.White
            Allclear.FlatAppearance.BorderColor = Color.Gray
            Squaresign.BackColor = Color.FromArgb(64, 64, 64)
            Squaresign.FlatStyle = FlatStyle.Flat
            Squaresign.ForeColor = Color.White
            Squaresign.FlatAppearance.BorderColor = Color.Gray
            Sqrtsign.BackColor = Color.FromArgb(64, 64, 64)
            Sqrtsign.FlatStyle = FlatStyle.Flat
            Sqrtsign.ForeColor = Color.White
            Sqrtsign.FlatAppearance.BorderColor = Color.Gray
            Backspace.BackColor = Color.FromArgb(64, 64, 64)
            Backspace.FlatStyle = FlatStyle.Flat
            Backspace.ForeColor = Color.White
            Backspace.FlatAppearance.BorderColor = Color.Gray
            Num7.BackColor = Color.FromArgb(64, 64, 64)
            Num7.FlatStyle = FlatStyle.Flat
            Num7.ForeColor = Color.White
            Num7.FlatAppearance.BorderColor = Color.Gray
            Num8.BackColor = Color.FromArgb(64, 64, 64)
            Num8.FlatStyle = FlatStyle.Flat
            Num8.ForeColor = Color.White
            Num8.FlatAppearance.BorderColor = Color.Gray
            Num9.BackColor = Color.FromArgb(64, 64, 64)
            Num9.FlatStyle = FlatStyle.Flat
            Num9.ForeColor = Color.White
            Num9.FlatAppearance.BorderColor = Color.Gray
            Num4.BackColor = Color.FromArgb(64, 64, 64)
            Num4.FlatStyle = FlatStyle.Flat
            Num4.ForeColor = Color.White
            Num4.FlatAppearance.BorderColor = Color.Gray
            Num5.BackColor = Color.FromArgb(64, 64, 64)
            Num5.FlatStyle = FlatStyle.Flat
            Num5.ForeColor = Color.White
            Num5.FlatAppearance.BorderColor = Color.Gray
            Num6.BackColor = Color.FromArgb(64, 64, 64)
            Num6.FlatStyle = FlatStyle.Flat
            Num6.ForeColor = Color.White
            Num6.FlatAppearance.BorderColor = Color.Gray
            Num1.BackColor = Color.FromArgb(64, 64, 64)
            Num1.FlatStyle = FlatStyle.Flat
            Num1.ForeColor = Color.White
            Num1.FlatAppearance.BorderColor = Color.Gray
            Num2.BackColor = Color.FromArgb(64, 64, 64)
            Num2.FlatStyle = FlatStyle.Flat
            Num2.ForeColor = Color.White
            Num2.FlatAppearance.BorderColor = Color.Gray
            Num3.BackColor = Color.FromArgb(64, 64, 64)
            Num3.FlatStyle = FlatStyle.Flat
            Num3.ForeColor = Color.White
            Num3.FlatAppearance.BorderColor = Color.Gray
            Num0.BackColor = Color.FromArgb(64, 64, 64)
            Num0.FlatStyle = FlatStyle.Flat
            Num0.ForeColor = Color.White
            Num0.FlatAppearance.BorderColor = Color.Gray
            Multiplysign.BackColor = Color.FromArgb(64, 64, 64)
            Multiplysign.FlatStyle = FlatStyle.Flat
            Multiplysign.ForeColor = Color.White
            Multiplysign.FlatAppearance.BorderColor = Color.Gray
            Dividesign.BackColor = Color.FromArgb(64, 64, 64)
            Dividesign.FlatStyle = FlatStyle.Flat
            Dividesign.ForeColor = Color.White
            Dividesign.FlatAppearance.BorderColor = Color.Gray
            Addsign.BackColor = Color.FromArgb(64, 64, 64)
            Addsign.FlatStyle = FlatStyle.Flat
            Addsign.ForeColor = Color.White
            Addsign.FlatAppearance.BorderColor = Color.Gray
            Subtractsign.BackColor = Color.FromArgb(64, 64, 64)
            Subtractsign.FlatStyle = FlatStyle.Flat
            Subtractsign.ForeColor = Color.White
            Subtractsign.FlatAppearance.BorderColor = Color.Gray
            Decimalsign.BackColor = Color.FromArgb(64, 64, 64)
            Decimalsign.FlatStyle = FlatStyle.Flat
            Decimalsign.ForeColor = Color.White
            Decimalsign.FlatAppearance.BorderColor = Color.Gray
            Equalsign.BackColor = Color.FromArgb(64, 64, 64)
            Equalsign.FlatStyle = FlatStyle.Flat
            Equalsign.ForeColor = Color.White
            Equalsign.FlatAppearance.BorderColor = Color.Gray
            Updatecheck.BackColor = Color.FromArgb(64, 64, 64)
            Updatecheck.FlatStyle = FlatStyle.Flat
            Updatecheck.ForeColor = Color.White
            Updatecheck.FlatAppearance.BorderColor = Color.Gray
            Aboutbutton.BackColor = Color.FromArgb(64, 64, 64)
            Aboutbutton.FlatStyle = FlatStyle.Flat
            Aboutbutton.ForeColor = Color.White
            Aboutbutton.FlatAppearance.BorderColor = Color.Gray
            Mode.BackColor = Color.FromArgb(64, 64, 64)
            Mode.FlatStyle = FlatStyle.Flat
            Mode.ForeColor = Color.White
            Mode.FlatAppearance.BorderColor = Color.Gray
            AutoUpdate.BackColor = Color.FromArgb(64, 64, 64)
            AutoUpdate.FlatStyle = FlatStyle.Flat
            AutoUpdate.ForeColor = Color.White
            AutoUpdate.FlatAppearance.BorderColor = Color.Gray
            Label1.ForeColor = Color.White
        ElseIf My.Settings.Darkmodeon = True Then
        My.Settings.Darkmodeon = False
            Me.Close()
            Process.Start(exepath)
        End If
    End Sub

    Private Sub Backspace_Click(sender As Object, e As EventArgs) Handles Backspace.Click
        If TextBox1.Text.Length <> 1 Or 0 Then
            TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1)
        ElseIf TextBox1.Text.Length = 1 Then
            TextBox1.Text = "0"
        End If
    End Sub

    Private Sub AutoUpdate_Click(sender As Object, e As EventArgs) Handles AutoUpdate.Click
        If My.Settings.AutoUpdateON = False Then
            My.Settings.AutoUpdateON = True
            AutoUpdate.Text = "Auto Update: ON"
            Dim wb As New WebClient
            Dim wbhtml As String = wb.DownloadString("https://rishaankotian.wixsite.com/home/v3-0-0")
            Dim StringContain As Boolean = wbhtml.Contains("Newest")
            'Checks if website has "Newest"
            If (StringContain = False) Then
                MessageBox.Show("eCal has a new update. To update eCal, click check for updates", "Updates available", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            My.Settings.AutoUpdateON = False
            AutoUpdate.Text = "Auto Update: OFF"
        End If
    End Sub
End Class
